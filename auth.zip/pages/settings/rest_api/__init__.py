from pages.settings.rest_api import rest_api_settings

__all__ = ["rest_api_settings"]
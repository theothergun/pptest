class WorkerName:
    DEVICE = "device"
    JOB = "job"
    TCP_CLIENT = "tcp_client"
    REST_API = "rest_api"
    SCRIPT = "script_worker"
    TWINCAT = "twincat"
    # add more here

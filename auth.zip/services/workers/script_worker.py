# services/workers/script_worker.py
from __future__ import annotations

import time
import threading
import queue
from dataclasses import dataclass
from typing import Any, Callable

from services.workers.base_worker import BaseWorker
from services.ui_bridge import UiBridge
from services.worker_bus import WorkerBus, BusMessage
from services.worker_commands import ScriptWorkerCommands as Commands
from services.worker_topics import WorkerTopics as Topics

from services.workers.stepchain.context import StepChainContext
from services.workers.stepchain.loader import ScriptLoader


KEY_SCRIPTS_LIST = "script.scripts_list"			# snapshot list[str]
KEY_CHAINS_LIST = "script.chains_list"			# snapshot list[dict]
KEY_CHAIN_STATE = "script.chain_state"			# legacy stream (last writer wins)
KEY_CHAIN_STATE_PREFIX = "script.chain_state."	# per-chain stream (recommended)
KEY_LOG = "script.log"

# Custom command string (does not require worker_commands enum changes)
CMD_SET_HOT_RELOAD = "SET_HOT_RELOAD"


@dataclass
class ChainInstance:
	script_name: str
	instance_id: str
	context: StepChainContext
	fn: Callable[[StepChainContext], None]
	active: bool = True
	paused: bool = False
	next_tick_ts: float = 0.0


class ScriptWorker(BaseWorker):
	def __init__(
		self,
		name: str,
		bridge: UiBridge,
		worker_bus: WorkerBus,
		commands: "queue.Queue[tuple[str, dict[str, Any]]]",
		stop: threading.Event,
		send_cmd,
	) -> None:
		super(ScriptWorker, self).__init__(
			name=name,
			bridge=bridge,
			worker_bus=worker_bus,
			commands=commands,
			stop=stop,
			send_cmd=send_cmd,
		)

		self.loader = ScriptLoader(scripts_dir="scripts")
		self.chains: dict[str, ChainInstance] = {}

		# Hot reload polling (disabled by default; enable via Scripts Lab)
		self.hot_reload_enabled = False
		self.last_reload_check = time.time()
		self.reload_check_interval = 1.0

		self._last_scripts: list[str] = []
		self._last_chain_sig = ""

		self.ui_state_sub = bridge.subscribe_many(["state", "state.*"])
		self.ui_state = bridge

		self.bus_sub = worker_bus.subscribe_many([
			Topics.VALUE_CHANGED,
			Topics.CLIENT_CONNECTED,
			Topics.CLIENT_DISCONNECTED,
			Topics.WRITE_FINISHED,
			Topics.WRITE_ERROR,
			Topics.ERROR,
		])

	# ------------------------------------------------------------------ publish helpers

	def _publish_as(self, source_id: str, key: str, value: Any) -> None:
		"""
		Single publishing gate to standardize attribution.
		BaseWorker.publish_value uses self.current_source_id, so set it here only.
		"""
		self.current_source_id = str(source_id or "")
		self.publish_value(key, value)

	def _chain_state_key(self, chain_key: str) -> str:
		"""
		Per-chain state key. Avoid characters that may be awkward in key-based stores.
		"""
		safe = str(chain_key or "").replace(":", "__").replace("/", "_")
		return "%s%s" % (KEY_CHAIN_STATE_PREFIX, safe)

	# ------------------------------------------------------------------ snapshots

	def _get_scripts_list(self) -> list[str]:
		try:
			return sorted(self.loader.list_available_scripts())
		except Exception:
			return []

	def _publish_scripts_if_changed(self, force: bool) -> None:
		scripts = self._get_scripts_list()
		if force or scripts != self._last_scripts:
			self._last_scripts = list(scripts)
			self._publish_as("script_worker", KEY_SCRIPTS_LIST, list(scripts))

	def _build_chain_list(self) -> list[dict[str, Any]]:
		items: list[dict[str, Any]] = []
		for key, inst in sorted(self.chains.items()):
			items.append({
				"key": key,
				"script": inst.script_name,
				"instance": inst.instance_id,
				"active": inst.active,
				"paused": inst.paused,
				"step": getattr(inst.context, "step", 0),
				"cycle_count": getattr(inst.context, "cycle_count", 0),
			})
		return items

	def _publish_chains_if_changed(self, force: bool) -> None:
		lst = self._build_chain_list()

		sig_parts: list[str] = []
		for x in lst:
			sig_parts.append("%s:%s:%s:%s:%s" % (
				x.get("key"),
				int(bool(x.get("active"))),
				int(bool(x.get("paused"))),
				int(x.get("step") or 0),
				int(x.get("cycle_count") or 0),
			))
		sig = "|".join(sig_parts)

		if force or sig != self._last_chain_sig:
			self._last_chain_sig = sig
			self._publish_as("script_worker", KEY_CHAINS_LIST, lst)

	def _stop_chain(self, chain_key: str, reason: str) -> None:
		inst = self.chains.get(chain_key)
		if not inst or not inst.active:
			return

		inst.active = False

		try:
			close_fn = getattr(inst.context, "close", None)
			if callable(close_fn):
				close_fn()
		except Exception:
			pass

		self.log.info("[_stop_chain] - stopped - chain_key=%s reason=%s" % (chain_key, reason))
		self._publish_chains_if_changed(True)

	# ------------------------------------------------------------------ hot reload apply

	def _apply_reloaded_scripts(self, reloaded: list[str]) -> None:
		"""
		Update running chain callables after loader reload.
		Otherwise chains keep calling a cached function object.
		"""
		if not reloaded:
			return

		updated = 0
		for inst in self.chains.values():
			if not inst.active:
				continue
			if inst.script_name not in reloaded:
				continue

			try:
				info = self.loader.scripts.get(inst.script_name)
				if info and callable(info.function):
					inst.fn = info.function
					updated += 1
			except Exception:
				pass

		if updated:
			self.log.info("[_apply_reloaded_scripts] - updated running chains - updated=%s scripts=%s" % (updated, reloaded))

	# ------------------------------------------------------------------ bus -> ctx.data

	def _apply_bus_msg_to_ctx(self, ctx: StepChainContext, msg: BusMessage) -> None:
		"""
		Standard mapping (source-first):
		ctx.data[source][source_id] = payload

	This keeps compatibility with existing scripts that access ctx.data by worker/source.
		"""
		try:
			if msg.topic == Topics.VALUE_CHANGED:
				source = getattr(msg, "source", "") or ""
				source_id = getattr(msg, "source_id", "") or ""
				payload = getattr(msg, "payload", None) or {}

				if not source:
					source = "unknown"

				if source not in ctx.data:
					ctx.data[source] = {}

				ctx.data[source][source_id] = payload

		except Exception as ex:
			self.log.error("[_apply_bus_msg_to_ctx] - failed - error=%s" % str(ex))

	def _drain_bus_updates(self, max_items: int) -> None:
		for _ in range(max_items):
			try:
				msg = self.bus_sub.queue.get_nowait()
			except queue.Empty:
				break

			for inst in self.chains.values():
				if not inst.active:
					continue
				self._apply_bus_msg_to_ctx(inst.context, msg)

	# ------------------------------------------------------------------ timing helpers

	def _get_cycle_time_s(self, ctx: StepChainContext) -> float:
		"""
		Per-instance sleep interval. Uses ctx.cycle_time if present.
		Guards against None/invalid/<=0.
		"""
		try:
			v = getattr(ctx, "cycle_time", None)
			if v is None:
				return 0.1
			vf = float(v)
			if vf <= 0:
				return 0.1
			return vf
		except Exception:
			return 0.1

	# ------------------------------------------------------------------ lifecycle

	def run(self) -> None:
		self.log.info("[run] - started")

		self._publish_scripts_if_changed(True)
		self._publish_chains_if_changed(True)

		# Main loop is "scheduler-like": each chain ticks on its own cadence
		while not self.stop_event.is_set():
			now = time.time()

			# Poll hot reload only if enabled
			if self.hot_reload_enabled and self.reload_check_interval > 0:
				if (now - self.last_reload_check) >= self.reload_check_interval:
					self.last_reload_check = now
					try:
						reloaded = self.loader.check_for_updates()
						if reloaded:
							self._apply_reloaded_scripts(reloaded)
							self._publish_scripts_if_changed(True)
					except Exception as ex:
						self.publish_error(key="script_worker", action="hot_reload", error=str(ex))

			self._drain_bus_updates(400)
			self._process_commands()

			next_due_ts = None

			for chain_key, inst in list(self.chains.items()):
				if not inst.active:
					continue

				# Decide when this instance should run next (per-context cadence)
				if inst.next_tick_ts <= 0:
					inst.next_tick_ts = now

				if inst.paused:
					if next_due_ts is None or inst.next_tick_ts < next_due_ts:
						next_due_ts = inst.next_tick_ts
					continue

				if now < inst.next_tick_ts:
					if next_due_ts is None or inst.next_tick_ts < next_due_ts:
						next_due_ts = inst.next_tick_ts
					continue

				inst.context.cycle_count = inst.context.cycle_count + 1

				try:
					start = time.time()
					inst.fn(inst.context)
					inst.context.step_time = time.time() - start
					inst.context.step = inst.context.next_step

				except Exception as ex:
					self.log.error("[run] - chain crashed - chain_key=%s error=%s" % (chain_key, str(ex)))
					self.publish_error(key=chain_key, action="chain_tick", error=str(ex))
					self._stop_chain(chain_key, "exception")
					continue

				# Schedule next tick for THIS instance based on THIS instance's ctx.cycle_time
				cycle_s = self._get_cycle_time_s(inst.context)
				inst.next_tick_ts = time.time() + cycle_s
				if next_due_ts is None or inst.next_tick_ts < next_due_ts:
					next_due_ts = inst.next_tick_ts

				# Publish state:
				# - Per-chain key (recommended; no overwrites between chains)
				# - Legacy KEY_CHAIN_STATE (kept for compatibility; last writer wins)
				try:
					state_payload = {
						"chain_key": chain_key,
						"state": inst.context.get_state(),
					}
					self._publish_as(chain_key, self._chain_state_key(chain_key), state_payload)
					self._publish_as(chain_key, KEY_CHAIN_STATE, state_payload)
				except Exception as ex:
					self.publish_error(key=chain_key, action="publish_chain_state", error=str(ex))

			# Sleep until the next chain is due, but wake up frequently enough for commands/bus/hot reload.
			# Cap sleep to keep UI responsive even if no chains are running.
			if next_due_ts is None:
				sleep_s = 0.05
			else:
				sleep_s = next_due_ts - time.time()
				if sleep_s < 0:
					sleep_s = 0.0
				if sleep_s > 0.2:
					sleep_s = 0.2

			time.sleep(sleep_s)

		try:
			self.bus_sub.close()
		except Exception:
			pass
		try:
			self.ui_state_sub.close()
		except Exception:
			pass

		self.log.info("[run] - stopped")

	def _process_commands(self) -> None:
		while True:
			try:
				cmd, payload = self.commands.get_nowait()
			except queue.Empty:
				break

			if cmd == "__stop__":
				return

			action = str(cmd or "")
			payload = payload or {}

			# If hot reload is disabled, do not reload opportunistically just because commands arrive.
			if self.hot_reload_enabled:
				try:
					reloaded = self.loader.check_for_updates()
					if reloaded:
						self._apply_reloaded_scripts(reloaded)
						self._publish_scripts_if_changed(True)
				except Exception as ex:
					self.publish_error(key="script_worker", action="check_for_updates", error=str(ex))

			if action == CMD_SET_HOT_RELOAD:
				try:
					enabled = bool(payload.get("enabled", False))
					interval = payload.get("interval", None)

					self.hot_reload_enabled = enabled

					if interval is not None:
						try:
							self.reload_check_interval = float(interval)
						except Exception:
							pass

					# Reset timing to avoid immediate burst reload on enable
					self.last_reload_check = time.time()

					self.log.info("[_process_commands] - set hot reload - enabled=%s interval=%s" % (
						int(bool(self.hot_reload_enabled)),
						self.reload_check_interval,
					))
				except Exception as ex:
					self.publish_error(key="script_worker", action="set_hot_reload", error=str(ex))

			elif action == str(Commands.RELOAD_ALL):
				try:
					reloaded = self.loader.reload_all()
					if reloaded:
						self._apply_reloaded_scripts(reloaded)
					self._publish_scripts_if_changed(True)
				except Exception as ex:
					self.publish_error(key="script_worker", action="reload_all", error=str(ex))

			elif action == str(Commands.LIST_SCRIPTS):
				self._publish_scripts_if_changed(True)

			elif action == str(Commands.LIST_CHAINS):
				self._publish_chains_if_changed(True)

			elif action == str(Commands.START_CHAIN):
				script_name = payload.get("script") or payload.get("script_name")
				instance_id = payload.get("instance_id") or str(int(time.time() * 1000))
				if not script_name:
					self.publish_error(
						key="script_worker",
						action="start_chain",
						error="missing payload.script or payload.script_name",
					)
					continue

				try:
					fn = self.loader.load_script(str(script_name), force=True)
					if not fn:
						raise RuntimeError("script load failed")
				except Exception as ex:
					self.publish_error(key="script:%s" % str(script_name), action="start_chain", error=str(ex))
					continue

				chain_key = "%s:%s" % (str(script_name), str(instance_id))

				try:
					ctx = StepChainContext(
						chain_id=chain_key,
						worker_bus=self.worker_bus,
						bridge=self.bridge,
						state=self.ui_state,
					)
				except Exception as ex:
					self.publish_error(key=chain_key, action="create_ctx", error=str(ex))
					continue

				now = time.time()
				self.chains[chain_key] = ChainInstance(
					script_name=str(script_name),
					instance_id=str(instance_id),
					context=ctx,
					fn=fn,
					active=True,
					paused=False,
					next_tick_ts=now,
				)

				self._publish_chains_if_changed(True)

			elif action == str(Commands.STOP_CHAIN):
				chain_key = payload.get("chain_key")
				if chain_key:
					self._stop_chain(str(chain_key), "cmd")

			elif action == str(Commands.PAUSE_CHAIN):
				chain_key = payload.get("chain_key")
				inst = self.chains.get(str(chain_key or ""))
				if inst:
					inst.paused = True
					self._publish_chains_if_changed(True)

			elif action == str(Commands.RESUME_CHAIN):
				chain_key = payload.get("chain_key")
				inst = self.chains.get(str(chain_key or ""))
				if inst:
					inst.paused = False
					# Resume should run promptly if overdue
					if inst.next_tick_ts <= 0 or inst.next_tick_ts > time.time():
						inst.next_tick_ts = time.time()
					self._publish_chains_if_changed(True)

			elif action == str(Commands.RELOAD_SCRIPT):
				script_name = payload.get("script") or payload.get("script_name")
				if not script_name:
					self.publish_error(
						key="script_worker",
						action="reload_script",
						error="missing payload.script or payload.script_name",
					)
					continue
				try:
					fn = self.loader.load_script(str(script_name), force=True)
					if fn:
						# Update running chains immediately
						self._apply_reloaded_scripts([str(script_name)])
					self._publish_scripts_if_changed(True)
				except Exception as ex:
					self.publish_error(key="script:%s" % str(script_name), action="reload_script", error=str(ex))

from pages.settings.tcp_client import tcp_settings

__all__ = ["tcp_settings"]
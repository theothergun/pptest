"""
1113333355555

Demo Script - Simple test chain
Shows basic step chain functionality.
222
Steps:
  0: IDLE
 10: COUNT
 20: WAIT
 30: NOTIFY
"""
import time


def demo_chain(ctx):
	"""Simple demonstration chain."""

	step = ctx.step

	ctx.cycle_time = 1
	if step == 0:  # IDLE
		ctx.goto(10)
		#print (111)
		#print(ctx.step)
		ctx.data["test"] = 123
		time.sleep(0.3)
		ctx.step_desc = "puhhh....tttt."
	elif step == 10:  # COUNT
		ctx.step_desc = "puhhh.....1"
		ctx.goto(20)
		time.sleep(0.2)

	elif step == 20:  # COUNT
		ctx.step_desc = "puhhh.....13"
		ctx.goto(0)
		time.sleep(0.1)

# Export
chain = demo_chain
